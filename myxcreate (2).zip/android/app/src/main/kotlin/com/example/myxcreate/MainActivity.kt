package com.example.myxcreate

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
